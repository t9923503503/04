"use client";

import type {
  KotcCommandRequest,
  KotcCommandResponse,
  KotcCourtState,
  KotcJoinResult,
  KotcPresenceItem,
  KotcSessionSummary,
  KotcSnapshot,
} from "./types";

const API_BASE = "/api/kotc";

function asNumber(value: unknown, fallback = 0): number {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.trim() ? value : fallback;
}

function asIdString(value: unknown, fallback = ""): string {
  if (typeof value === "string" && value.trim()) return value;
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return fallback;
}

function asObject(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : {};
}

function asArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function toTimestamp(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const direct = Number(value);
    if (Number.isFinite(direct)) return direct;
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) return parsed;
  }
  return null;
}

async function readJson<T>(res: Response): Promise<T | null> {
  try {
    const data = (await res.json()) as T;
    return data;
  } catch {
    return null;
  }
}

function buildHeaders(seatToken?: string): HeadersInit {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
  };
  if (seatToken) {
    headers.Authorization = `Bearer ${seatToken}`;
    headers["X-KOTC-Seat-Token"] = seatToken;
  }
  return headers;
}

function normalizeCourt(raw: unknown, fallbackIdx: number): KotcCourtState {
  const obj = asObject(raw);
  return {
    courtIdx: asNumber(obj.courtIdx ?? obj.court_idx, fallbackIdx),
    courtVersion: asNumber(obj.courtVersion ?? obj.court_version, 0),
    roundIdx: asNumber(obj.roundIdx ?? obj.round_idx, 0),
    scores: asObject(obj.scores),
    timerStatus: asString(obj.timerStatus ?? obj.timer_status, ""),
    timerDurationMs: asNumber(obj.timerDurationMs ?? obj.timer_duration_ms, 0),
    timerEndsAt: toTimestamp(obj.timerEndsAt ?? obj.timer_ends_at),
    timerPausedAt: toTimestamp(obj.timerPausedAt ?? obj.timer_paused_at),
    updatedAt: asString(obj.updatedAt ?? obj.updated_at, ""),
  };
}

function normalizePresence(raw: unknown): KotcPresenceItem {
  const obj = asObject(raw);
  const roleRaw = asString(obj.role, "viewer");
  const role = roleRaw === "hub" || roleRaw === "judge" ? roleRaw : "viewer";
  return {
    seatId: asIdString(obj.seatId ?? obj.seat_id),
    role,
    courtIdx:
      obj.courtIdx === null || obj.court_idx === null
        ? null
        : asNumber(obj.courtIdx ?? obj.court_idx, 0),
    displayName: asString(obj.displayName ?? obj.display_name),
    isOnline:
      typeof obj.isOnline === "boolean"
        ? obj.isOnline
        : typeof obj.is_online === "boolean"
          ? obj.is_online
          : undefined,
    leaseUntil: asString(obj.leaseUntil ?? obj.lease_until) || null,
    lastSeenAt: asString(obj.lastSeenAt ?? obj.last_seen_at) || null,
  };
}

function normalizeSnapshot(raw: unknown, fallbackSessionId: string): KotcSnapshot {
  const obj = asObject(raw);
  const sessionObj = asObject(obj.session);
  const snapshotObj = Object.keys(sessionObj).length > 0 ? sessionObj : obj;
  const courtsRaw = asObject(obj.courts);
  const courts: Record<number, KotcCourtState> = {};

  for (const [key, value] of Object.entries(courtsRaw)) {
    const idx = asNumber(key, -1);
    if (idx >= 0) courts[idx] = normalizeCourt(value, idx);
  }
  const courtsList = asArray(obj.courtsList ?? obj.courts_list ?? obj.courtsArray ?? obj.courts_array);
  for (const value of courtsList) {
    const normalized = normalizeCourt(value, 0);
    courts[normalized.courtIdx] = normalized;
  }

  const presence = asArray(obj.presence ?? obj.seats ?? obj.items ?? obj.data).map(normalizePresence);

  return {
    sessionId: asString(snapshotObj.sessionId ?? snapshotObj.session_id, fallbackSessionId),
    sessionVersion: asNumber(snapshotObj.sessionVersion ?? snapshotObj.session_version, 0),
    structureEpoch: asNumber(snapshotObj.structureEpoch ?? snapshotObj.structure_epoch, 0),
    phase: asString(snapshotObj.phase, ""),
    nc: asNumber(snapshotObj.nc, Math.max(1, Object.keys(courts).length || 4)),
    courts,
    presence,
    global: asObject(obj.global ?? snapshotObj.state ?? snapshotObj.state_json),
  };
}

function normalizeSessionSummary(raw: unknown): KotcSessionSummary {
  const obj = asObject(raw);
  return {
    sessionId: asString(obj.sessionId ?? obj.session_id),
    tournamentId: asString(obj.tournamentId ?? obj.tournament_id),
    title: asString(obj.title ?? obj.name),
    status: asString(obj.status),
    phase: asString(obj.phase),
    nc: asNumber(obj.nc, 4),
    updatedAt: asString(obj.updatedAt ?? obj.updated_at),
  };
}

function normalizeJoin(raw: unknown, fallbackSessionId: string): KotcJoinResult {
  const obj = asObject(raw);
  const seatObj = asObject(obj.seat);
  const roleRaw = asString(seatObj.role ?? obj.role, "viewer");
  const role = roleRaw === "hub" || roleRaw === "judge" ? roleRaw : "viewer";
  const seatToken = asString(obj.seatToken ?? obj.seat_token);
  const seat = {
    seatId: asIdString(seatObj.seatId ?? seatObj.seat_id),
    role,
    courtIdx:
      seatObj.courtIdx === null || seatObj.court_idx === null
        ? null
        : asNumber(seatObj.courtIdx ?? seatObj.court_idx, 0),
    displayName: asString(seatObj.displayName ?? seatObj.display_name),
  } as const;
  const snapshot = normalizeSnapshot(obj.snapshot ?? obj, fallbackSessionId);
  return {
    sessionId: snapshot.sessionId || fallbackSessionId,
    seatToken,
    seat,
    snapshot,
  };
}

export async function listSessions(): Promise<KotcSessionSummary[]> {
  const res = await fetch(`${API_BASE}/sessions/active`, {
    method: "GET",
    cache: "no-store",
    headers: { Accept: "application/json" },
  });
  if (!res.ok) {
    const error = new Error(`Failed to load sessions: ${res.status}`);
    (error as Error & { status?: number }).status = res.status;
    throw error;
  }
  const data = await readJson<unknown>(res);
  const rawList = Array.isArray(data)
    ? data
    : asArray(asObject(data).sessions ?? asObject(data).items ?? asObject(data).data);
  return rawList.map(normalizeSessionSummary).filter((item) => item.sessionId);
}

export async function joinSession(input: {
  sessionId: string;
  roleHint?: "hub" | "judge" | "viewer";
  courtIdx?: number;
  displayName?: string;
  deviceId: string;
  reclaim?: boolean;
  seatToken?: string | null;
}): Promise<KotcJoinResult> {
  const body = {
    role: input.roleHint,
    roleHint: input.roleHint,
    courtIdx: input.courtIdx,
    court_idx: input.courtIdx,
    displayName: input.displayName,
    display_name: input.displayName,
    deviceId: input.deviceId,
    device_id: input.deviceId,
    reclaim: Boolean(input.reclaim),
  };
  const res = await fetch(`${API_BASE}/sessions/${encodeURIComponent(input.sessionId)}/join`, {
    method: "POST",
    headers: buildHeaders(input.seatToken || undefined),
    body: JSON.stringify(body),
  });
  const data = await readJson<unknown>(res);
  if (!res.ok) {
    const message =
      asString(asObject(data).error) ||
      asString(asObject(data).message) ||
      `Join failed (${res.status})`;
    const error = new Error(message);
    (error as Error & { status?: number }).status = res.status;
    throw error;
  }
  const dataObj = asObject(data);
  if (dataObj.joined === false) {
    const occupiedBy = asObject(dataObj.occupiedBy ?? dataObj.occupied_by);
    const occupiedName = asString(occupiedBy.displayName ?? occupiedBy.display_name);
    const reason = asString(dataObj.reason, "Join failed");
    throw new Error(occupiedName ? `${reason}: ${occupiedName}` : reason);
  }
  return normalizeJoin(data, input.sessionId);
}

export async function releaseSeat(sessionId: string, seatToken: string): Promise<void> {
  const res = await fetch(`${API_BASE}/sessions/${encodeURIComponent(sessionId)}/release`, {
    method: "POST",
    headers: buildHeaders(seatToken),
    body: JSON.stringify({}),
  });
  if (!res.ok) {
    const data = await readJson<unknown>(res);
    throw new Error(asString(asObject(data).error, `Release failed (${res.status})`));
  }
}

export async function fetchSnapshot(
  sessionId: string,
  scope: "global" | "full",
  seatToken?: string | null,
): Promise<KotcSnapshot> {
  const url = `${API_BASE}/sessions/${encodeURIComponent(sessionId)}/snapshot?scope=${scope}`;
  const res = await fetch(url, {
    method: "GET",
    cache: "no-store",
    headers: buildHeaders(seatToken || undefined),
  });
  const data = await readJson<unknown>(res);
  if (!res.ok) {
    throw new Error(asString(asObject(data).error, `Snapshot failed (${res.status})`));
  }
  return normalizeSnapshot(data, sessionId);
}

export async function fetchCourt(
  sessionId: string,
  courtIdx: number,
  seatToken?: string | null,
): Promise<KotcCourtState> {
  const url = `${API_BASE}/sessions/${encodeURIComponent(sessionId)}/courts/${courtIdx}`;
  const res = await fetch(url, {
    method: "GET",
    cache: "no-store",
    headers: buildHeaders(seatToken || undefined),
  });
  const data = await readJson<unknown>(res);
  if (!res.ok) {
    throw new Error(asString(asObject(data).error, `Court snapshot failed (${res.status})`));
  }
  return normalizeCourt(data, courtIdx);
}

export async function fetchPresence(
  sessionId: string,
  seatToken?: string | null,
): Promise<KotcPresenceItem[]> {
  const url = `${API_BASE}/sessions/${encodeURIComponent(sessionId)}/presence`;
  const res = await fetch(url, {
    method: "GET",
    cache: "no-store",
    headers: buildHeaders(seatToken || undefined),
  });
  const data = await readJson<unknown>(res);
  if (!res.ok) {
    throw new Error(asString(asObject(data).error, `Presence failed (${res.status})`));
  }
  const list = Array.isArray(data)
    ? data
    : asArray(asObject(data).presence ?? asObject(data).seats ?? asObject(data).items ?? asObject(data).data);
  return list.map(normalizePresence);
}

export async function sendCommand(
  request: KotcCommandRequest,
  seatToken?: string | null,
): Promise<KotcCommandResponse> {
  const commandId =
    request.commandId ??
    (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `cmd_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`);

  const body = {
    command_id: commandId,
    commandType: request.commandType,
    command_type: request.commandType,
    scope: request.scope,
    courtIdx: request.courtIdx,
    court_idx: request.courtIdx,
    expectedVersion: request.expectedVersion,
    expected_version: request.expectedVersion,
    expectedCourtVersion: request.expectedCourtVersion,
    expected_court_version: request.expectedCourtVersion,
    expectedStructureEpoch: request.expectedStructureEpoch,
    expected_structure_epoch: request.expectedStructureEpoch,
    payload: request.payload ?? {},
  };
  const res = await fetch(`${API_BASE}/sessions/${encodeURIComponent(request.sessionId)}/commands`, {
    method: "POST",
    headers: buildHeaders(seatToken || undefined),
    body: JSON.stringify(body),
  });
  const data = await readJson<unknown>(res);
  if (!res.ok) {
    const message =
      asString(asObject(data).error) ||
      asString(asObject(data).message) ||
      `Command failed (${res.status})`;
    const error = new Error(message);
    (error as Error & { status?: number }).status = res.status;
    (error as Error & { payload?: unknown }).payload = data;
    throw error;
  }
  const obj = asObject(data);
  return {
    success: Boolean(obj.success ?? true),
    appliedCommand: asString(obj.appliedCommand ?? obj.applied_command),
    sessionVersion: asNumber(obj.sessionVersion ?? obj.session_version, 0),
    structureEpoch: asNumber(obj.structureEpoch ?? obj.structure_epoch, 0),
    courtVersion: asNumber(obj.courtVersion ?? obj.court_version, 0),
    divisionVersion: asNumber(obj.divisionVersion ?? obj.division_version, 0),
    delta: obj.delta ? asObject(obj.delta) : null,
    serverNow: asNumber(obj.serverNow ?? obj.server_now, Date.now()),
  };
}
