"use client";

import { useState, useEffect } from "react";
import { useKotcLiveStore } from "../use-kotc-live-store";
import { SessionList } from "../judge/SessionList";
import { formatMs, getRemainingMs } from "../judge/utils";
import type { KotcCourtState } from "../types";

export function KotcLiveHubFlow() {
  const { state, actions } = useKotcLiveStore();
  const {
    backToSessionList,
    joinAs,
    refreshPresence,
    refreshSessions,
    runCommand,
    selectSession,
  } = actions;
  const [busy, setBusy] = useState(false);
  const [tick, setTick] = useState(Date.now());
  const [broadcastMessage, setBroadcastMessage] = useState("");

  useEffect(() => {
    const timer = setInterval(() => setTick(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!state.selectedSessionId) return;
    void refreshPresence();
    const timer = setInterval(() => {
      void refreshPresence();
    }, 12_000);
    return () => clearInterval(timer);
  }, [refreshPresence, state.selectedSessionId]);

  // Hub automatically selects the session if there's only 1 active
  useEffect(() => {
    if (!state.selectedSessionId && state.sessions.length === 1 && !state.loading && !busy) {
      void selectSession(state.sessions[0].sessionId);
    }
  }, [busy, selectSession, state.loading, state.selectedSessionId, state.sessions]);

  // If session is selected but we haven't joined, auto-join as Hub
  useEffect(() => {
    if (state.selectedSessionId && !state.role && !state.loading && !busy) {
      setBusy(true);
      void joinAs("hub").finally(() => setBusy(false));
    }
  }, [busy, joinAs, state.loading, state.role, state.selectedSessionId]);

  const runHubCommand = async (commandType: string, payload: Record<string, unknown>) => {
    if (busy) return;
    setBusy(true);
    try {
      await runCommand({
        commandType,
        scope: "global",
        expectedStructureEpoch: state.structureEpoch,
        payload,
      });
    } finally {
      setBusy(false);
    }
  };

  const forceRelease = async (courtIdx: number) => {
    if (!confirm(`Вы уверены, что хотите принудительно освободить Корт ${courtIdx}?`)) return;
    await runHubCommand("seat.force_release", { courtIdx, court_idx: courtIdx });
  };

  if (state.loading && !state.selectedSessionId) {
    return (
      <div className="flex h-[50vh] items-center justify-center text-text-secondary">
        <div className="w-8 h-8 rounded-full border-2 border-brand/50 border-t-brand animate-spin mr-3" />
        Connecting to KOTC Hub...
      </div>
    );
  }

  if (!state.selectedSessionId) {
    return (
      <div className="w-full max-w-4xl mx-auto px-4">
        <SessionList
          sessions={state.sessions}
          loading={state.loading}
          onSelect={(id) => selectSession(id)}
          onRefresh={() => refreshSessions()}
        />
      </div>
    );
  }

  if (state.role !== "hub") {
    return (
      <div className="flex h-[50vh] items-center justify-center text-text-secondary">
        <div className="w-6 h-6 rounded-full border-2 border-brand border-t-transparent animate-spin mr-3" />
        Joining as Hub...
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto px-4 pb-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <h1 className="font-heading text-2xl text-text-primary">Hub Control Board</h1>
          <span className="px-2 py-1 rounded bg-emerald-500/10 text-emerald-300 text-xs border border-emerald-500/20">
            {state.connectionStatus}
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs font-body text-text-secondary">
          <span>Session: {state.sessionVersion}</span>
          <span>Epoch: {state.structureEpoch}</span>
          <button 
            onClick={() => backToSessionList()}
            className="px-3 py-1.5 rounded border border-white/10 hover:border-white/30 text-white"
          >
            Leave Hub
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* EMERGENCY CONTROLS */}
        <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-5 flex flex-col gap-4">
          <h2 className="font-heading text-xl text-red-200 uppercase tracking-widest text-sm mb-2">
            Emergency Controls
          </h2>
          
          <div className="flex flex-wrap gap-3">
            <button
              disabled={busy}
              onClick={() => runHubCommand("session.pause", {})}
              className="rounded-lg border border-amber-500/40 bg-amber-500/20 px-4 py-3 text-sm font-semibold text-amber-200 disabled:opacity-50 hover:bg-amber-500/30 transition-colors flex-1"
            >
              Pause Session
            </button>
            <button
              disabled={busy}
              onClick={() => runHubCommand("session.resume", {})}
              className="rounded-lg border border-emerald-500/40 bg-emerald-500/20 px-4 py-3 text-sm font-semibold text-emerald-300 disabled:opacity-50 hover:bg-emerald-500/30 transition-colors flex-1"
            >
              Resume Session
            </button>
          </div>

          <div className="mt-2 text-sm text-text-secondary border-t border-white/10 pt-4">
             Broadcasting alerts will blink on all judges screens (if implemented).
          </div>
          <div className="flex gap-2 w-full">
            <input
              type="text"
              value={broadcastMessage}
              onChange={(e) => setBroadcastMessage(e.target.value)}
              placeholder="Message to all courts..."
              className="flex-1 rounded-lg border border-white/20 bg-surface/80 px-3 py-2 text-sm text-text-primary outline-none focus:border-cyan-500/50"
            />
            <button
              disabled={busy || !broadcastMessage.trim()}
              onClick={() => runHubCommand("global.broadcast_message", { message: broadcastMessage.trim() }).then(() => setBroadcastMessage(""))}
              className="rounded-lg border border-cyan-500/40 bg-cyan-500/20 px-4 py-2 text-sm font-semibold text-cyan-200 disabled:opacity-50 hover:bg-cyan-500/30 transition-colors"
            >
              Send
            </button>
          </div>
        </div>

        {/* JUDGES PRESENCE */}
        <div className="rounded-xl border border-white/10 bg-surface-light/30 p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-heading text-xl text-text-primary uppercase tracking-widest text-sm">
              Judge Matrix
            </h2>
            <button onClick={() => refreshPresence()} disabled={busy} className="text-xs text-brand hover:underline">
              Refresh
            </button>
          </div>
          
          <div className="flex flex-col gap-2">
            {Array.from({ length: state.nc || 4 }, (_, offset) => offset + 1).map((idx) => {
              const seat = state.presence.find((p) => p.courtIdx === idx && p.role === "judge");
              return (
                <div key={idx} className="flex items-center justify-between rounded-lg border border-white/5 bg-surface/50 p-3">
                  <div className="flex items-center gap-3">
                    <span className="font-heading text-lg text-text-primary w-24">Court {idx}</span>
                    {seat ? (
                      <div className="flex flex-col">
                        <span className="text-sm font-semibold text-emerald-300">{seat.displayName || "Unknown Judge"}</span>
                        <span className="text-xs text-text-secondary">{seat.isOnline ? "Online" : "Offline / Unreachable"}</span>
                      </div>
                    ) : (
                      <span className="text-sm text-text-secondary italic">Empty / Available</span>
                    )}
                  </div>
                  {seat && (
                    <button
                      disabled={busy}
                      onClick={() => forceRelease(idx)}
                      className="px-3 py-1.5 text-xs rounded border border-red-500/40 text-red-300 hover:bg-red-500/20 active:bg-red-500/40 transition-colors"
                    >
                      Force Release
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* COURTS LIVE OVERVIEW */}
      <div className="rounded-xl border border-white/10 bg-surface/40 p-5 mt-6">
        <h2 className="font-heading text-xl text-text-primary uppercase tracking-widest text-sm mb-4">
          Courts Live Readout
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: state.nc || 4 }, (_, offset) => offset + 1).map((idx) => {
            const court = state.courts[idx];
            if (!court) {
              return (
                <div key={idx} className="rounded-lg border border-white/5 bg-surface-light/20 p-4 text-center text-text-secondary text-sm">
                  Court {idx} Pending
                </div>
              )
            }
            const raw = (court.scores || {}) as Record<string, unknown>;
            const home = Number(raw.home ?? raw.teamA ?? 0);
            const away = Number(raw.away ?? raw.teamB ?? 0);
            const remainingMs = getRemainingMs(court, state.clockOffsetMs);
            
            return (
              <div key={idx} className="rounded-lg border border-white/10 bg-surface-light/40 p-4">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-heading font-bold">Court {idx}</span>
                  <span className="text-xs font-mono text-text-secondary">{court.timerStatus || "idle"}</span>
                </div>
                <div className="text-3xl font-heading text-center tracking-widest text-emerald-300 mb-4 bg-black/20 py-2 rounded">
                  {formatMs(remainingMs)}
                </div>
                <div className="flex justify-between px-2 text-2xl font-bold font-heading">
                  <span>{home}</span>
                  <span className="text-text-secondary text-sm self-center">:</span>
                  <span>{away}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
