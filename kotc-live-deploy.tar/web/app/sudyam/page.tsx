import type { Metadata } from "next";
import { headers } from "next/headers";
import SudyamLiveClient from "@/components/kotc-live/SudyamLiveClient";

export const metadata: Metadata = {
  title: "Sudyam | Lutyye Plyazhniki",
  description: "KOTC judge workspace with live seats, court controls, scores, and timers.",
};

function buildLegacyIframeSrc(host: string, proto: string): string {
  const siteUrl = host ? `${proto}://${host}/` : "/";
  const configuredKotcUrl = String(process.env.NEXT_PUBLIC_KOTC_URL || "").trim();
  const kotcUrl =
    configuredKotcUrl && !(process.env.NODE_ENV === "production" && configuredKotcUrl.includes("localhost"))
      ? configuredKotcUrl
      : host
        ? `${proto}://${host}/kotc/`
        : "/kotc/";

  try {
    const url = new URL(kotcUrl);
    url.searchParams.set("siteUrl", siteUrl);
    url.searchParams.set("startTab", "roster");
    return url.toString();
  } catch {
    const sep = kotcUrl.includes("?") ? "&" : "?";
    return `${kotcUrl}${sep}siteUrl=${encodeURIComponent(siteUrl)}&startTab=roster`;
  }
}

// Middleware already validates sudyam_session, so this route is authenticated.
export default async function SudyamPage() {
  const headerStore = await headers();
  const host = headerStore.get("x-forwarded-host") ?? headerStore.get("host") ?? "";
  const proto = headerStore.get("x-forwarded-proto") ?? (host.includes("localhost") ? "http" : "https");
  const legacyIframeSrc = buildLegacyIframeSrc(host, proto);

  return <SudyamLiveClient legacyIframeSrc={legacyIframeSrc} />;
}
